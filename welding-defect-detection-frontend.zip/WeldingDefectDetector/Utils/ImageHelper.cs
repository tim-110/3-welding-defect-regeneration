using System;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace WeldingDefectDetector.Utils
{
    /// <summary>
    /// 图像处理工具类
    /// </summary>
    public static class ImageHelper
    {
        /// <summary>
        /// 将图像转换为Base64字符串
        /// </summary>
        public static string ImageToBase64(Image image, ImageFormat format)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                // 将图像保存到内存流
                image.Save(ms, format);
                
                // 将内存流中的内容转换为字节数组
                byte[] imageBytes = ms.ToArray();
                
                // 将字节数组转换为Base64字符串
                return Convert.ToBase64String(imageBytes);
            }
        }

        /// <summary>
        /// 将Base64字符串转换为图像
        /// </summary>
        public static Image Base64ToImage(string base64String)
        {
            // 将Base64字符串转换为字节数组
            byte[] imageBytes = Convert.FromBase64String(base64String);
            
            // 将字节数组转换为内存流
            using (MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length))
            {
                // 从内存流创建图像
                ms.Write(imageBytes, 0, imageBytes.Length);
                return Image.FromStream(ms, true);
            }
        }

        /// <summary>
        /// 在图像上绘制缺陷标记
        /// </summary>
        public static Image DrawDefectMarkers(Image image, Models.DetectionResult detectionResult)
        {
            // 创建图像的副本以避免修改原始图像
            Image markedImage = new Bitmap(image);
            
            using (Graphics g = Graphics.FromImage(markedImage))
            {
                foreach (var defect in detectionResult.Defects)
                {
                    // 绘制矩形框标记缺陷位置
                    using (Pen pen = new Pen(Color.Red, 2))
                    {
                        g.DrawRectangle(
                            pen, 
                            defect.Location.X, 
                            defect.Location.Y, 
                            defect.Location.Width, 
                            defect.Location.Height
                        );
                    }
                    
                    // 绘制缺陷类型和置信度文本
                    string text = $"{defect.Type} ({defect.Confidence:P0})";
                    using (Font font = new Font("Arial", 10, FontStyle.Bold))
                    using (Brush brush = new SolidBrush(Color.Red))
                    {
                        g.DrawString(
                            text, 
                            font, 
                            brush, 
                            defect.Location.X, 
                            defect.Location.Y - 20
                        );
                    }
                }
            }
            
            return markedImage;
        }
    }
}
