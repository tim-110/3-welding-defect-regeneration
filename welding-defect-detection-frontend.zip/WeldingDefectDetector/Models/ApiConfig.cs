namespace WeldingDefectDetector.Models
{
    /// <summary>
    /// API配置，存储后端服务地址
    /// </summary>
    public class ApiConfig
    {
        public string RustBackendUrl { get; set; } = "http://127.0.0.1:8080";
        public string PythonModelUrl { get; set; } = "http://127.0.0.1:5000";
    }
}
