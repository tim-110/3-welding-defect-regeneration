using System.Collections.Generic;

namespace WeldingDefectDetector.Models
{
    /// <summary>
    /// 缺陷位置信息
    /// </summary>
    public class DefectLocation
    {
        public int X { get; set; }         // 缺陷左上角X坐标
        public int Y { get; set; }         // 缺陷左上角Y坐标
        public int Width { get; set; }     // 缺陷宽度
        public int Height { get; set; }    // 缺陷高度
    }

    /// <summary>
    /// 单个缺陷信息
    /// </summary>
    public class Defect
    {
        public string Type { get; set; }       // 缺陷类型
        public double Confidence { get; set; } // 置信度(0-1)
        public DefectLocation Location { get; set; } // 缺陷位置
    }

    /// <summary>
    /// 检测结果
    /// </summary>
    public class DetectionResult
    {
        public bool Success { get; set; }              // 检测是否成功
        public string Message { get; set; }            // 消息
        public string ImageBase64 { get; set; }        // 带标注的图像Base64
        public List<Defect> Defects { get; set; } = new List<Defect>(); // 缺陷列表
        public string DetectionTime { get; set; }      // 检测时间
        public string ImageName { get; set; }          // 图像名称
    }

    /// <summary>
    /// 历史记录项
    /// </summary>
    public class HistoryRecord
    {
        public int Id { get; set; }                  // 记录ID
        public string ImageName { get; set; }        // 图像名称
        public string DetectionTime { get; set; }    // 检测时间
        public int DefectCount { get; set; }         // 缺陷数量
        public string DefectTypes { get; set; }      // 缺陷类型，用逗号分隔
    }

    /// <summary>
    /// 服务健康状态
    /// </summary>
    public class ServiceHealth
    {
        public bool ModelLoaded { get; set; }
        public Dictionary<string, string> Services { get; set; } = new Dictionary<string, string>();
    }
}
