using System;
using System.Windows.Forms;
using WeldingDefectDetector.Models;
using WeldingDefectDetector.Utils;

namespace WeldingDefectDetector.Forms
{
    public partial class HistoryDetailForm : Form
    {
        private readonly DetectionResult _detectionResult;

        public HistoryDetailForm(DetectionResult detectionResult)
        {
            InitializeComponent();
            _detectionResult = detectionResult;
            LoadDetectionResult();
        }

        private void LoadDetectionResult()
        {
            // 显示基本信息
            lblImageName.Text = _detectionResult.ImageName;
            lblDetectionTime.Text = _detectionResult.DetectionTime;
            lblDefectCount.Text = _detectionResult.Defects.Count.ToString();
            
            // 显示结果图像
            if (!string.IsNullOrEmpty(_detectionResult.ImageBase64))
            {
                try
                {
                    pbResult.Image = ImageHelper.Base64ToImage(_detectionResult.ImageBase64);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"加载图像失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
            // 显示缺陷列表
            lstDefects.Items.Clear();
            foreach (var defect in _detectionResult.Defects)
            {
                var item = new ListViewItem($"类型: {defect.Type}");
                item.SubItems.Add($"置信度: {defect.Confidence:P0}");
                item.SubItems.Add($"位置: X={defect.Location.X}, Y={defect.Location.Y}, 宽={defect.Location.Width}, 高={defect.Location.Height}");
                lstDefects.Items.Add(item);
            }
        }

        #region Windows 窗体设计器生成的代码
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblImageName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblDetectionTime = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblDefectCount = new System.Windows.Forms.Label();
            this.pbResult = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lstDefects = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbResult)).BeginInit();
            this.SuspendLayout();
            
            // label1
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "图像名称";
            
            // lblImageName
            this.lblImageName.AutoSize = true;
            this.lblImageName.Location = new System.Drawing.Point(100, 30);
            this.lblImageName.Name = "lblImageName";
            this.lblImageName.Size = new System.Drawing.Size(0, 12);
            this.lblImageName.TabIndex = 1;
            
            // label3
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "检测时间";
            
            // lblDetectionTime
            this.lblDetectionTime.AutoSize = true;
            this.lblDetectionTime.Location = new System.Drawing.Point(100, 60);
            this.lblDetectionTime.Name = "lblDetectionTime";
            this.lblDetectionTime.Size = new System.Drawing.Size(0, 12);
            this.lblDetectionTime.TabIndex = 3;
            
            // label5
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "缺陷数量";
            
            // lblDefectCount
            this.lblDefectCount.AutoSize = true;
            this.lblDefectCount.Location = new System.Drawing.Point(100, 90);
            this.lblDefectCount.Name = "lblDefectCount";
            this.lblDefectCount.Size = new System.Drawing.Size(0, 12);
            this.lblDefectCount.TabIndex = 5;
            
            // pbResult
            this.pbResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbResult.Location = new System.Drawing.Point(30, 120);
            this.pbResult.Name = "pbResult";
            this.pbResult.Size = new System.Drawing.Size(600, 400);
            this.pbResult.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbResult.TabIndex = 6;
            this.pbResult.TabStop = false;
            
            // label2
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 540);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "缺陷列表";
            
            // lstDefects
            this.lstDefects.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lstDefects.Location = new System.Drawing.Point(30, 560);
            this.lstDefects.Name = "lstDefects";
            this.lstDefects.Size = new System.Drawing.Size(600, 150);
            this.lstDefects.TabIndex = 8;
            this.lstDefects.UseCompatibleStateImageBehavior = false;
            this.lstDefects.View = System.Windows.Forms.View.Details;
            
            // columnHeader1
            this.columnHeader1.Text = "缺陷类型";
            this.columnHeader1.Width = 150;
            
            // columnHeader2
            this.columnHeader2.Text = "置信度";
            this.columnHeader2.Width = 100;
            
            // columnHeader3
            this.columnHeader3.Text = "位置信息";
            this.columnHeader3.Width = 330;
            
            // btnClose
            this.btnClose.Location = new System.Drawing.Point(550, 730);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(80, 30);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            
            // HistoryDetailForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 780);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lstDefects);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pbResult);
            this.Controls.Add(this.lblDefectCount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblDetectionTime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblImageName);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "HistoryDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "检测历史详情";
            ((System.ComponentModel.ISupportInitialize)(this.pbResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblImageName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblDetectionTime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblDefectCount;
        private System.Windows.Forms.PictureBox pbResult;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView lstDefects;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button btnClose;

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
