using System;
using System.Windows.Forms;
using WeldingDefectDetector.Models;
using WeldingDefectDetector.Network;
using WeldingDefectDetector.Utils;

namespace WeldingDefectDetector.Forms
{
    public partial class HistoryForm : Form
    {
        private readonly ApiClient _apiClient;

        public HistoryForm(ApiClient apiClient)
        {
            InitializeComponent();
            _apiClient = apiClient;
            
            // 加载时获取历史记录
            Load += async (s, e) => await LoadHistoryRecordsAsync();
        }

        private async void btnRefresh_Click(object sender, EventArgs e)
        {
            await LoadHistoryRecordsAsync();
        }

        private async System.Threading.Tasks.Task LoadHistoryRecordsAsync()
        {
            try
            {
                btnRefresh.Enabled = false;
                btnViewDetail.Enabled = false;
                lblStatus.Text = "正在加载历史记录...";
                dgvHistory.Rows.Clear();
                
                var records = await _apiClient.GetHistoryRecordsAsync();
                
                foreach (var record in records)
                {
                    dgvHistory.Rows.Add(
                        record.Id,
                        record.ImageName,
                        record.DetectionTime,
                        record.DefectCount,
                        record.DefectTypes
                    );
                }
                
                lblStatus.Text = $"共加载 {records.Count} 条历史记录";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载历史记录失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "加载历史记录失败";
            }
            finally
            {
                btnRefresh.Enabled = true;
            }
        }

        private void dgvHistory_SelectionChanged(object sender, EventArgs e)
        {
            // 当选中行变化时，更新查看详情按钮状态
            btnViewDetail.Enabled = dgvHistory.SelectedRows.Count > 0;
        }

        private async void btnViewDetail_Click(object sender, EventArgs e)
        {
            if (dgvHistory.SelectedRows.Count == 0)
            {
                MessageBox.Show("请先选择一条记录", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            try
            {
                // 获取选中记录的ID
                var recordId = (int)dgvHistory.SelectedRows[0].Cells[0].Value;
                
                // 显示加载状态
                btnViewDetail.Enabled = false;
                lblStatus.Text = "正在加载记录详情...";
                
                // 获取记录详情
                var result = await _apiClient.GetHistoryDetailAsync(recordId);
                
                if (result.Success)
                {
                    // 显示详情窗口
                    using (var detailForm = new HistoryDetailForm(result))
                    {
                        detailForm.ShowDialog();
                    }
                    
                    lblStatus.Text = "记录详情加载完成";
                }
                else
                {
                    MessageBox.Show($"加载详情失败: {result.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载详情出错: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnViewDetail.Enabled = true;
            }
        }

        #region Windows 窗体设计器生成的代码
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvHistory = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnViewDetail = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImageName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDetectionTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDefectCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDefectTypes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).BeginInit();
            this.SuspendLayout();
            
            // dgvHistory
            this.dgvHistory.AllowUserToAddRows = false;
            this.dgvHistory.AllowUserToDeleteRows = false;
            this.dgvHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colId,
            this.colImageName,
            this.colDetectionTime,
            this.colDefectCount,
            this.colDefectTypes});
            this.dgvHistory.Location = new System.Drawing.Point(30, 70);
            this.dgvHistory.MultiSelect = false;
            this.dgvHistory.Name = "dgvHistory";
            this.dgvHistory.ReadOnly = true;
            this.dgvHistory.RowTemplate.Height = 23;
            this.dgvHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHistory.Size = new System.Drawing.Size(750, 400);
            this.dgvHistory.TabIndex = 0;
            this.dgvHistory.SelectionChanged += new System.EventHandler(this.dgvHistory_SelectionChanged);
            
            // btnRefresh
            this.btnRefresh.Location = new System.Drawing.Point(30, 30);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 30);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "刷新记录";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            
            // btnViewDetail
            this.btnViewDetail.Enabled = false;
            this.btnViewDetail.Location = new System.Drawing.Point(150, 30);
            this.btnViewDetail.Name = "btnViewDetail";
            this.btnViewDetail.Size = new System.Drawing.Size(100, 30);
            this.btnViewDetail.TabIndex = 2;
            this.btnViewDetail.Text = "查看详情";
            this.btnViewDetail.UseVisualStyleBackColor = true;
            this.btnViewDetail.Click += new System.EventHandler(this.btnViewDetail_Click);
            
            // lblStatus
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(280, 40);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 12);
            this.lblStatus.TabIndex = 3;
            
            // colId
            this.colId.HeaderText = "ID";
            this.colId.Name = "colId";
            this.colId.ReadOnly = true;
            this.colId.Width = 50;
            
            // colImageName
            this.colImageName.HeaderText = "图像名称";
            this.colImageName.Name = "colImageName";
            this.colImageName.ReadOnly = true;
            this.colImageName.Width = 150;
            
            // colDetectionTime
            this.colDetectionTime.HeaderText = "检测时间";
            this.colDetectionTime.Name = "colDetectionTime";
            this.colDetectionTime.ReadOnly = true;
            this.colDetectionTime.Width = 150;
            
            // colDefectCount
            this.colDefectCount.HeaderText = "缺陷数量";
            this.colDefectCount.Name = "colDefectCount";
            this.colDefectCount.ReadOnly = true;
            this.colDefectCount.Width = 80;
            
            // colDefectTypes
            this.colDefectTypes.HeaderText = "缺陷类型";
            this.colDefectTypes.Name = "colDefectTypes";
            this.colDefectTypes.ReadOnly = true;
            this.colDefectTypes.Width = 300;
            
            // HistoryForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 500);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnViewDetail);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgvHistory);
            this.Name = "HistoryForm";
            this.Text = "检测历史";
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DataGridView dgvHistory;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnViewDetail;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colImageName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDetectionTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDefectCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDefectTypes;
        #endregion
    }
}
