using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using WeldingDefectDetector.Models;
using WeldingDefectDetector.Network;
using WeldingDefectDetector.Utils;

namespace WeldingDefectDetector.Forms
{
    public partial class DetectionForm : Form
    {
        private readonly ApiClient _apiClient;
        private Image _selectedImage;
        private string _imageFileName;
        private DetectionResult _currentResult;

        public DetectionForm(ApiClient apiClient)
        {
            InitializeComponent();
            _apiClient = apiClient;
        }

        private void btnSelectImage_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "图像文件|*.jpg;*.jpeg;*.png;*.bmp|所有文件|*.*";
                openFileDialog.Title = "选择焊接图像";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // 加载选中的图像
                        _imageFileName = Path.GetFileName(openFileDialog.FileName);
                        _selectedImage = Image.FromFile(openFileDialog.FileName);
                        
                        // 显示原始图像
                        pbOriginal.Image = _selectedImage;
                        pbResult.Image = null;
                        
                        // 清空结果信息
                        lstDefects.Items.Clear();
                        _currentResult = null;
                        
                        // 启用检测按钮
                        btnDetect.Enabled = true;
                        lblStatus.Text = $"已加载图像: {_imageFileName}";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"加载图像失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        lblStatus.Text = "加载图像失败";
                    }
                }
            }
        }

        private async void btnDetect_Click(object sender, EventArgs e)
        {
            if (_selectedImage == null)
            {
                MessageBox.Show("请先选择图像", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                // 准备检测
                btnDetect.Enabled = false;
                btnSelectImage.Enabled = false;
                lblStatus.Text = "正在进行缺陷检测，请稍候...";
                
                // 将图像转换为Base64
                string imageBase64 = ImageHelper.ImageToBase64(_selectedImage, System.Drawing.Imaging.ImageFormat.Jpeg);
                
                // 调用API进行检测
                _currentResult = await _apiClient.DetectDefectsAsync(imageBase64, _imageFileName);
                
                if (_currentResult.Success)
                {
                    // 显示检测结果图像
                    if (!string.IsNullOrEmpty(_currentResult.ImageBase64))
                    {
                        pbResult.Image = ImageHelper.Base64ToImage(_currentResult.ImageBase64);
                    }
                    else
                    {
                        // 如果后端没有返回带标注的图像，前端自己绘制
                        pbResult.Image = ImageHelper.DrawDefectMarkers(_selectedImage, _currentResult);
                    }
                    
                    // 显示缺陷列表
                    lstDefects.Items.Clear();
                    foreach (var defect in _currentResult.Defects)
                    {
                        var item = new ListViewItem($"类型: {defect.Type}");
                        item.SubItems.Add($"置信度: {defect.Confidence:P0}");
                        item.SubItems.Add($"位置: X={defect.Location.X}, Y={defect.Location.Y}, 宽={defect.Location.Width}, 高={defect.Location.Height}");
                        lstDefects.Items.Add(item);
                    }
                    
                    lblStatus.Text = $"检测完成，共发现 {_currentResult.Defects.Count} 个缺陷";
                    
                    // 启用保存按钮
                    btnSaveResult.Enabled = true;
                }
                else
                {
                    MessageBox.Show($"检测失败: {_currentResult.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    lblStatus.Text = "检测失败";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"检测过程出错: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "检测过程出错";
            }
            finally
            {
                // 恢复状态
                btnDetect.Enabled = true;
                btnSelectImage.Enabled = true;
            }
        }

        private void btnSaveResult_Click(object sender, EventArgs e)
        {
            if (_currentResult == null || pbResult.Image == null)
            {
                MessageBox.Show("没有可保存的检测结果", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "JPEG图像|*.jpg|PNG图像|*.png|所有文件|*.*";
                saveFileDialog.Title = "保存检测结果";
                saveFileDialog.FileName = $"result_{Path.GetFileNameWithoutExtension(_imageFileName)}.jpg";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // 保存带标注的图像
                        pbResult.Image.Save(saveFileDialog.FileName);
                        
                        // 可以在这里添加保存缺陷详细信息到文本文件的逻辑
                        
                        lblStatus.Text = $"检测结果已保存到: {saveFileDialog.FileName}";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"保存失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        #region Windows 窗体设计器生成的代码
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            
            // 释放图像资源
            if (_selectedImage != null)
            {
                _selectedImage.Dispose();
            }
            
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnSelectImage = new System.Windows.Forms.Button();
            this.btnDetect = new System.Windows.Forms.Button();
            this.btnSaveResult = new System.Windows.Forms.Button();
            this.pbOriginal = new System.Windows.Forms.PictureBox();
            this.pbResult = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lstDefects = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label3 = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbOriginal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbResult)).BeginInit();
            this.SuspendLayout();
            
            // btnSelectImage
            this.btnSelectImage.Location = new System.Drawing.Point(30, 30);
            this.btnSelectImage.Name = "btnSelectImage";
            this.btnSelectImage.Size = new System.Drawing.Size(100, 30);
            this.btnSelectImage.TabIndex = 0;
            this.btnSelectImage.Text = "选择图像";
            this.btnSelectImage.UseVisualStyleBackColor = true;
            this.btnSelectImage.Click += new System.EventHandler(this.btnSelectImage_Click);
            
            // btnDetect
            this.btnDetect.Enabled = false;
            this.btnDetect.Location = new System.Drawing.Point(150, 30);
            this.btnDetect.Name = "btnDetect";
            this.btnDetect.Size = new System.Drawing.Size(100, 30);
            this.btnDetect.TabIndex = 1;
            this.btnDetect.Text = "开始检测";
            this.btnDetect.UseVisualStyleBackColor = true;
            this.btnDetect.Click += new System.EventHandler(this.btnDetect_Click);
            
            // btnSaveResult
            this.btnSaveResult.Enabled = false;
            this.btnSaveResult.Location = new System.Drawing.Point(270, 30);
            this.btnSaveResult.Name = "btnSaveResult";
            this.btnSaveResult.Size = new System.Drawing.Size(100, 30);
            this.btnSaveResult.TabIndex = 2;
            this.btnSaveResult.Text = "保存结果";
            this.btnSaveResult.UseVisualStyleBackColor = true;
            this.btnSaveResult.Click += new System.EventHandler(this.btnSaveResult_Click);
            
            // pbOriginal
            this.pbOriginal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbOriginal.Location = new System.Drawing.Point(30, 100);
            this.pbOriginal.Name = "pbOriginal";
            this.pbOriginal.Size = new System.Drawing.Size(350, 300);
            this.pbOriginal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbOriginal.TabIndex = 3;
            this.pbOriginal.TabStop = false;
            
            // pbResult
            this.pbResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbResult.Location = new System.Drawing.Point(420, 100);
            this.pbResult.Name = "pbResult";
            this.pbResult.Size = new System.Drawing.Size(350, 300);
            this.pbResult.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbResult.TabIndex = 4;
            this.pbResult.TabStop = false;
            
            // label1
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "原始图";
            
            // label2
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(420, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "检测结果";
            
            // lstDefects
            this.lstDefects.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lstDefects.Location = new System.Drawing.Point(30, 430);
            this.lstDefects.Name = "lstDefects";
            this.lstDefects.Size = new System.Drawing.Size(740, 100);
            this.lstDefects.TabIndex = 7;
            this.lstDefects.UseCompatibleStateImageBehavior = false;
            this.lstDefects.View = System.Windows.Forms.View.Details;
            
            // columnHeader1
            this.columnHeader1.Text = "缺陷类型";
            this.columnHeader1.Width = 150;
            
            // columnHeader2
            this.columnHeader2.Text = "置信度";
            this.columnHeader2.Width = 100;
            
            // columnHeader3
            this.columnHeader3.Text = "位置信息";
            this.columnHeader3.Width = 450;
            
            // label3
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 415);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "缺陷列表";
            
            // lblStatus
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(400, 40);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 12);
            this.lblStatus.TabIndex = 9;
            
            // DetectionForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 560);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lstDefects);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbResult);
            this.Controls.Add(this.pbOriginal);
            this.Controls.Add(this.btnSaveResult);
            this.Controls.Add(this.btnDetect);
            this.Controls.Add(this.btnSelectImage);
            this.Name = "DetectionForm";
            this.Text = "缺陷检测";
            ((System.ComponentModel.ISupportInitialize)(this.pbOriginal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btnSelectImage;
        private System.Windows.Forms.Button btnDetect;
        private System.Windows.Forms.Button btnSaveResult;
        private System.Windows.Forms.PictureBox pbOriginal;
        private System.Windows.Forms.PictureBox pbResult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView lstDefects;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblStatus;
        #endregion
    }
}
