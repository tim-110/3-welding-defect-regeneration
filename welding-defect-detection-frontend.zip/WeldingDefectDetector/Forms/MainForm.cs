using System;
using System.Windows.Forms;
using WeldingDefectDetector.Models;
using WeldingDefectDetector.Network;

namespace WeldingDefectDetector.Forms
{
    public partial class MainForm : Form
    {
        private readonly ApiClient _apiClient;
        private readonly ApiConfig _apiConfig;
        
        // 子界面
        private DetectionForm _detectionForm;
        private HistoryForm _historyForm;
        private SettingsForm _settingsForm;
        private HomeForm _homeForm;

        public MainForm()
        {
            InitializeComponent();
            
            // 初始化配置和API客户端
            _apiConfig = new ApiConfig();
            _apiClient = new ApiClient(_apiConfig);
            
            // 初始化子界面
            InitializeChildForms();
        }

        private void InitializeChildForms()
        {
            // 创建子界面实例
            _homeForm = new HomeForm(_apiClient);
            _detectionForm = new DetectionForm(_apiClient);
            _historyForm = new HistoryForm(_apiClient);
            _settingsForm = new SettingsForm(_apiConfig);
            
            // 设置子界面属性
            SetChildFormProperties(_homeForm);
            SetChildFormProperties(_detectionForm);
            SetChildFormProperties(_historyForm);
            SetChildFormProperties(_settingsForm);
            
            // 添加到面板
            pnlContent.Controls.Add(_homeForm);
            pnlContent.Controls.Add(_detectionForm);
            pnlContent.Controls.Add(_historyForm);
            pnlContent.Controls.Add(_settingsForm);
            
            // 默认显示首页
            ShowChildForm(_homeForm);
        }

        private void SetChildFormProperties(Form form)
        {
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            form.Visible = false;
        }

        private void ShowChildForm(Form form)
        {
            // 隐藏所有子界面
            foreach (Control control in pnlContent.Controls)
            {
                if (control is Form childForm)
                {
                    childForm.Visible = false;
                }
            }
            
            // 显示选中的子界面
            form.Visible = true;
            form.BringToFront();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            ShowChildForm(_homeForm);
        }

        private void btnDetection_Click(object sender, EventArgs e)
        {
            ShowChildForm(_detectionForm);
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            ShowChildForm(_historyForm);
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            ShowChildForm(_settingsForm);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        #region Windows 窗体设计器生成的代码
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnHistory = new System.Windows.Forms.Button();
            this.btnDetection = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.pnlContent = new System.Windows.Forms.Panel();
            this.pnlSidebar.SuspendLayout();
            this.SuspendLayout();
            
            // pnlSidebar
            this.pnlSidebar.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlSidebar.Controls.Add(this.btnExit);
            this.pnlSidebar.Controls.Add(this.btnSettings);
            this.pnlSidebar.Controls.Add(this.btnHistory);
            this.pnlSidebar.Controls.Add(this.btnDetection);
            this.pnlSidebar.Controls.Add(this.btnHome);
            this.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlSidebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSidebar.Name = "pnlSidebar";
            this.pnlSidebar.Size = new System.Drawing.Size(150, 600);
            this.pnlSidebar.TabIndex = 0;
            
            // btnExit
            this.btnExit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnExit.Location = new System.Drawing.Point(0, 550);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(150, 50);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "退出";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            
            // btnSettings
            this.btnSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSettings.Location = new System.Drawing.Point(0, 200);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(150, 50);
            this.btnSettings.TabIndex = 3;
            this.btnSettings.Text = "系统设置";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            
            // btnHistory
            this.btnHistory.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHistory.Location = new System.Drawing.Point(0, 150);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(150, 50);
            this.btnHistory.TabIndex = 2;
            this.btnHistory.Text = "检测历史";
            this.btnHistory.UseVisualStyleBackColor = true;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            
            // btnDetection
            this.btnDetection.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDetection.Location = new System.Drawing.Point(0, 100);
            this.btnDetection.Name = "btnDetection";
            this.btnDetection.Size = new System.Drawing.Size(150, 50);
            this.btnDetection.TabIndex = 1;
            this.btnDetection.Text = "缺陷检测";
            this.btnDetection.UseVisualStyleBackColor = true;
            this.btnDetection.Click += new System.EventHandler(this.btnDetection_Click);
            
            // btnHome
            this.btnHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHome.Location = new System.Drawing.Point(0, 0);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(150, 50);
            this.btnHome.TabIndex = 0;
            this.btnHome.Text = "首页";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            
            // pnlContent
            this.pnlContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContent.Location = new System.Drawing.Point(150, 0);
            this.pnlContent.Name = "pnlContent";
            this.pnlContent.Size = new System.Drawing.Size(850, 600);
            this.pnlContent.TabIndex = 1;
            
            // MainForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.pnlSidebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "焊接缺陷智能检测系统";
            this.pnlSidebar.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnHistory;
        private System.Windows.Forms.Button btnDetection;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel pnlContent;
        #endregion
    }
}
