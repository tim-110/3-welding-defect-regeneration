using System;
using System.Windows.Forms;
using WeldingDefectDetector.Network;

namespace WeldingDefectDetector.Forms
{
    public partial class HomeForm : Form
    {
        private readonly ApiClient _apiClient;

        public HomeForm(ApiClient apiClient)
        {
            InitializeComponent();
            _apiClient = apiClient;
            
            // 加载时检查服务状态
            Load += async (s, e) => await CheckServiceStatusAsync();
        }

        private async void btnRefreshStatus_Click(object sender, EventArgs e)
        {
            await CheckServiceStatusAsync();
        }

        private async System.Threading.Tasks.Task CheckServiceStatusAsync()
        {
            try
            {
                btnRefreshStatus.Enabled = false;
                lblStatus.Text = "正在检查服务状态...";
                
                var health = await _apiClient.CheckHealthAsync();
                
                // 更新模型加载状态
                lblModelStatus.Text = health.ModelLoaded ? "已加载" : "未加载";
                lblModelStatus.ForeColor = health.ModelLoaded ? System.Drawing.Color.Green : System.Drawing.Color.Red;
                
                // 清空并更新服务状态列表
                lstServices.Items.Clear();
                foreach (var service in health.Services)
                {
                    var statusText = $"{service.Key}: {service.Value}";
                    var item = new ListViewItem(statusText);
                    
                    // 根据状态设置颜色
                    if (service.Value.Equals("healthy", StringComparison.OrdinalIgnoreCase))
                    {
                        item.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        item.ForeColor = System.Drawing.Color.Red;
                    }
                    
                    lstServices.Items.Add(item);
                }
                
                lblStatus.Text = "服务状态检查完成";
                lblStatus.ForeColor = System.Drawing.Color.Black;
            }
            catch (Exception ex)
            {
                lblStatus.Text = $"检查失败: {ex.Message}";
                lblStatus.ForeColor = System.Drawing.Color.Red;
            }
            finally
            {
                btnRefreshStatus.Enabled = true;
            }
        }

        #region Windows 窗体设计器生成的代码
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblModelStatus = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lstServices = new System.Windows.Forms.ListView();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRefreshStatus = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            
            // label1
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SimSun", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(30, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "焊接缺陷智能检测系统";
            
            // groupBox1
            this.groupBox1.Controls.Add(this.lblModelStatus);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lstServices);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(34, 80);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(750, 400);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "系统状态";
            
            // lblModelStatus
            this.lblModelStatus.AutoSize = true;
            this.lblModelStatus.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblModelStatus.Location = new System.Drawing.Point(120, 45);
            this.lblModelStatus.Name = "lblModelStatus";
            this.lblModelStatus.Size = new System.Drawing.Size(56, 14);
            this.lblModelStatus.TabIndex = 3;
            this.lblModelStatus.Text = "未知";
            
            // label3
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(30, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 14);
            this.label3.TabIndex = 2;
            this.label3.Text = "模型状态：";
            
            // lstServices
            this.lstServices.Location = new System.Drawing.Point(33, 90);
            this.lstServices.Name = "lstServices";
            this.lstServices.Size = new System.Drawing.Size(680, 280);
            this.lstServices.TabIndex = 1;
            this.lstServices.UseCompatibleStateImageBehavior = false;
            this.lstServices.View = System.Windows.Forms.View.List;
            
            // label2
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(30, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "服务状态：";
            
            // btnRefreshStatus
            this.btnRefreshStatus.Location = new System.Drawing.Point(34, 500);
            this.btnRefreshStatus.Name = "btnRefreshStatus";
            this.btnRefreshStatus.Size = new System.Drawing.Size(100, 30);
            this.btnRefreshStatus.TabIndex = 2;
            this.btnRefreshStatus.Text = "刷新状态";
            this.btnRefreshStatus.UseVisualStyleBackColor = true;
            this.btnRefreshStatus.Click += new System.EventHandler(this.btnRefreshStatus_Click);
            
            // lblStatus
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(150, 507);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 12);
            this.lblStatus.TabIndex = 3;
            
            // HomeForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 560);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnRefreshStatus);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "HomeForm";
            this.Text = "首页";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblModelStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lstServices;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRefreshStatus;
        private System.Windows.Forms.Label lblStatus;
        #endregion
    }
}
