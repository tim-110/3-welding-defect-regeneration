using System;
using System.Windows.Forms;
using WeldingDefectDetector.Models;

namespace WeldingDefectDetector.Forms
{
    public partial class SettingsForm : Form
    {
        private readonly ApiConfig _apiConfig;

        public SettingsForm(ApiConfig apiConfig)
        {
            InitializeComponent();
            _apiConfig = apiConfig;
            LoadSettings();
        }

        private void LoadSettings()
        {
            // 加载当前配置
            txtRustBackendUrl.Text = _apiConfig.RustBackendUrl;
            txtPythonModelUrl.Text = _apiConfig.PythonModelUrl;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // 简单验证URL格式
            if (!Uri.IsWellFormedUriString(txtRustBackendUrl.Text, UriKind.Absolute))
            {
                MessageBox.Show("Rust后端URL格式不正确", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            if (!Uri.IsWellFormedUriString(txtPythonModelUrl.Text, UriKind.Absolute))
            {
                MessageBox.Show("Python模型URL格式不正确", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            // 保存配置
            _apiConfig.RustBackendUrl = txtRustBackendUrl.Text;
            _apiConfig.PythonModelUrl = txtPythonModelUrl.Text;
            
            // 可以在这里添加将配置保存到文件的逻辑
            
            MessageBox.Show("配置已保存", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // 取消并恢复原始值
            LoadSettings();
        }

        #region Windows 窗体设计器生成的代码
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtRustBackendUrl = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPythonModelUrl = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            
            // label1
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rust后端地址:";
            
            // txtRustBackendUrl
            this.txtRustBackendUrl.Location = new System.Drawing.Point(150, 50);
            this.txtRustBackendUrl.Name = "txtRustBackendUrl";
            this.txtRustBackendUrl.Size = new System.Drawing.Size(400, 21);
            this.txtRustBackendUrl.TabIndex = 1;
            
            // label2
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Python模型地址:";
            
            // txtPythonModelUrl
            this.txtPythonModelUrl.Location = new System.Drawing.Point(150, 100);
            this.txtPythonModelUrl.Name = "txtPythonModelUrl";
            this.txtPythonModelUrl.Size = new System.Drawing.Size(400, 21);
            this.txtPythonModelUrl.TabIndex = 3;
            
            // btnSave
            this.btnSave.Location = new System.Drawing.Point(150, 150);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            
            // btnCancel
            this.btnCancel.Location = new System.Drawing.Point(270, 150);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            
            // SettingsForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 250);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtPythonModelUrl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtRustBackendUrl);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SettingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "系统设置";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRustBackendUrl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPythonModelUrl;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        #endregion
    }
}
