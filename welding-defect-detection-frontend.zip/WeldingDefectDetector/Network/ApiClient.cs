using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using WeldingDefectDetector.Models;

namespace WeldingDefectDetector.Network
{
    /// <summary>
    /// API客户端，负责与后端通信
    /// </summary>
    public class ApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly ApiConfig _apiConfig;

        public ApiClient(ApiConfig apiConfig)
        {
            _apiConfig = apiConfig;
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(30); // 设置超时时间
        }

        /// <summary>
        /// 检查服务健康状态
        /// </summary>
        public async Task<ServiceHealth> CheckHealthAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_apiConfig.RustBackendUrl}/health");
                response.EnsureSuccessStatusCode();
                
                var json = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<ServiceHealth>(json);
            }
            catch (Exception ex)
            {
                throw new Exception($"检查服务健康状态失败: {ex.Message}");
            }
        }

        /// <summary>
        /// 上传图像并进行缺陷检测
        /// </summary>
        public async Task<DetectionResult> DetectDefectsAsync(string imageBase64, string imageName)
        {
            try
            {
                var requestData = new
                {
                    image = imageBase64,
                    image_name = imageName
                };

                var jsonContent = new StringContent(
                    JsonConvert.SerializeObject(requestData),
                    Encoding.UTF8,
                    "application/json"
                );

                var response = await _httpClient.PostAsync($"{_apiConfig.RustBackendUrl}/detect", jsonContent);
                response.EnsureSuccessStatusCode();
                
                var json = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<DetectionResult>(json);
            }
            catch (Exception ex)
            {
                throw new Exception($"缺陷检测失败: {ex.Message}");
            }
        }

        /// <summary>
        /// 获取检测历史记录
        /// </summary>
        public async Task<List<HistoryRecord>> GetHistoryRecordsAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_apiConfig.RustBackendUrl}/history");
                response.EnsureSuccessStatusCode();
                
                var json = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<List<HistoryRecord>>(json);
            }
            catch (Exception ex)
            {
                throw new Exception($"获取历史记录失败: {ex.Message}");
            }
        }

        /// <summary>
        /// 获取历史记录详情
        /// </summary>
        public async Task<DetectionResult> GetHistoryDetailAsync(int recordId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"{_apiConfig.RustBackendUrl}/history/{recordId}");
                response.EnsureSuccessStatusCode();
                
                var json = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<DetectionResult>(json);
            }
            catch (Exception ex)
            {
                throw new Exception($"获取历史记录详情失败: {ex.Message}");
            }
        }
    }
}
